import tkinter as tk
from tkinter import messagebox, filedialog
import pandas as pd

# Load the CSV file into a DataFrame
try:
    df = pd.read_csv('profiles.csv')
except FileNotFoundError:
    df = pd.DataFrame(columns=['Email', 'Age', 'Gender', 'Country', 'Name', 'Job Title', 'Social Media Profile', 'Interests', 'Recent Activities', 'Affiliations', 'Contact Number'])

# Function to fetch profile information for a selected email
def fetch_profile():
    selected_email = email_listbox.get(tk.ACTIVE)
    if not selected_email:
        messagebox.showwarning("No Email Selected", "Please select an email to profile.")
        return
    
    try:
        profile_info = df[df['Email'] == selected_email].iloc[0]
        # Prepare profile information text
        profile_text.set(f"Email: {profile_info['Email']}\n"
                         f"Name: {profile_info['Name']}\n"
                         f"Age: {profile_info['Age']}\n"
                         f"Gender: {profile_info['Gender']}\n"
                         f"Country: {profile_info['Country']}\n"
                         f"Job Title: {profile_info['Job Title']}\n"
                         f"Social Media Profile: {profile_info['Social Media Profile']}\n"
                         f"Interests: {profile_info['Interests']}\n"
                         f"Recent Activities: {profile_info['Recent Activities']}\n"
                         f"Affiliations: {profile_info['Affiliations']}\n"
                         f"Contact Number: {profile_info['Contact Number']}")
        # Show dialog to proceed to profile
        proceed_dialog(selected_email)
    except IndexError:
        messagebox.showerror("Profile Not Found", f"No profile found for {selected_email}.")
        return

# Function to open a dialog for proceeding with profile
def proceed_dialog(email):
    result = messagebox.askyesno("Profile Selection", f"You have selected {email}. Proceed to profile?")
    if result == tk.YES:
        # Perform actions to profile the selected email
        # Here you can add further actions or function calls
        messagebox.showinfo("Profile", f"Profile selected: {email}")
    else:
        messagebox.showinfo("Profile", "Profile selection canceled.")

# Function to refresh the email listbox with current data
def refresh_email_list():
    emails = df['Email'].tolist()
    email_listbox.delete(0, tk.END)
    for email in emails:
        email_listbox.insert(tk.END, email)

# Function to upload and process manual CSV input
def upload_manual_csv():
    manual_csv_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    if not manual_csv_path:
        return
    
    try:
        manual_df = pd.read_csv(manual_csv_path)
        # Append the manual_df to df and drop duplicates based on 'Email'
        df = pd.concat([df, manual_df]).drop_duplicates(subset='Email', keep='last')
        df.to_csv('profiles.csv', index=False)
        messagebox.showinfo("CSV Upload", "Manual input CSV file processed and profiles updated successfully.")
        refresh_email_list()
    except FileNotFoundError:
        messagebox.showerror("File Not Found", f"File '{manual_csv_path}' not found.")
    except pd.errors.EmptyDataError:
        messagebox.showerror("Empty CSV", "The selected CSV file is empty.")
    except pd.errors.ParserError:
        messagebox.showerror("Parse Error", "Error parsing CSV file. Please check the file format.")

# GUI Setup
root = tk.Tk()
root.title("Profile Viewer")

# Frame for existing profiles
frame_profiles = tk.Frame(root, padx=10, pady=10)
frame_profiles.pack()

# Label for existing profiles
label_existing_profiles = tk.Label(frame_profiles, text="Existing Profiles")
label_existing_profiles.pack()

# Listbox to display email addresses
email_listbox = tk.Listbox(frame_profiles, width=40, height=10)
email_listbox.pack(pady=10)

# Button to fetch profile
fetch_button = tk.Button(frame_profiles, text="Fetch Profile", command=fetch_profile)
fetch_button.pack()

# Frame for manual CSV input
frame_manual_csv = tk.Frame(root, padx=10, pady=10)
frame_manual_csv.pack()

# Label for manual CSV input
label_manual_csv = tk.Label(frame_manual_csv, text="Manually Add CSV File")
label_manual_csv.pack()

# Entry for manual CSV path
manual_csv_entry = tk.Entry(frame_manual_csv, width=40)
manual_csv_entry.pack(pady=5)

# Button to upload manual CSV file
upload_button = tk.Button(frame_manual_csv, text="Upload CSV File", command=upload_manual_csv)
upload_button.pack()

# Text display for profile information
profile_text = tk.StringVar()
profile_label = tk.Label(root, textvariable=profile_text, padx=10, pady=10)
profile_label.pack()

# Initialize email listbox with existing emails
refresh_email_list()

# Start the GUI main loop
root.mainloop()
